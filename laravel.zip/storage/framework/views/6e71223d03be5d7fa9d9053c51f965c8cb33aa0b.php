

<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <h2>Edit Fund</h2>
            <a href="<?php echo e(route('fund.index')); ?>" class="btn btn-primary my-3">
            Back</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <Strong>Whoops!</Strong>
        There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('fund.update', $fund->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <strong>แหล่งทุน</strong>
                <input type="text" name="resource_funds" value="<?php echo e($fund->resource_funds); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong>ประเภททุน</strong>
                <input type="text" name="funds_category" value="<?php echo e($fund->funds_category); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong>ปีงบประมาณ</strong>
                <input type="text" name="fiscal_year" value="<?php echo e($fund->fiscal_year); ?>" class="form-control">
            </div>
        </div>
        
        <div class="col-md-12">
            <button type="submit" class="btn btn-success my-3">Update</button>
        </div>
    </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fund.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/fund/edit.blade.php ENDPATH**/ ?>