


<?php $__env->startSection('content'); ?>
<div class="row mt-5">
    <div class="col-md-12">
       
        <h2>Show Journals <?php echo e($journals->id); ?></h2>
        <a href="<?php echo e(route('journals.index')); ?>" class="btn btn-primary my-3">
        Back</a>
    </div>
</div>

<div class="row">
    <div class="card p-3">
        <div class="card-title">
            <strong>Journals information</strong>
        </div>
        <div class="border-top my-1"></div>
        <div class="card-text">
            <Strong>Journals name:</Strong>
            <?php echo e($journals->title); ?>

        </div>
        <div class="card-text">
            <Strong>Description:</Strong>
            <?php echo e($journals->description); ?>

        </div>
        
        
        
       
       
            
    
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('journals.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/journals/show.blade.php ENDPATH**/ ?>