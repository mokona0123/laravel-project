
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    

<?php $__env->startSection('content'); ?>
<div class="row mt-5">
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Funds')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
<div class="col-md-12">
    <a href="<?php echo e(route ('fund.create')); ?>" class="btn btn-success my-3">Create new funds</a>
    
</div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <?php echo e($message); ?>

</div>

<?php endif; ?>
<table class="table table-bordered">
    <tr>
        <th>No.</th>
        <th>แหล่งทุน</th>
        <th>ประเภททุน</th>
        <th>ปีงบประมาณ</th>
        <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($value->resource_funds); ?></td>
        <td><?php echo e(Str::limit($value->funds_category,100)); ?></td>
        <td><?php echo e($value->fiscal_year); ?></td>

        <td>
            <form action="<?php echo e(route('fund.destroy',$value->id)); ?>" method="post">
            <a href="<?php echo e(route('fund.show', $value->id)); ?>" class="btn btn-primary">Show</a>
            <a href="<?php echo e(route('fund.edit', $value->id)); ?>" class="btn btn-secondary">Edit</a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this?');">Delete</button>

            </form>
        </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php $__env->stopSection(); ?>
              
            
      
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php echo $__env->make('fund.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/fund/index.blade.php ENDPATH**/ ?>