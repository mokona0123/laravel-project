


<?php $__env->startSection('content'); ?>
<div class="row mt-5">
    <div class="col-md-12">
        <h2>Show Post</h2>
        <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary my-3">
        Back</a>
    </div>
</div>

<div class="row">
    <div class="card p-3">
        <div class="card-title">
            <h4>⏵ข้อมูลทุน</h4>
        </div>
        <div class="border-top my-1"></div>
        <div class="card-text">
            <Strong>แหล่งทุน:</Strong>
            <u class="dotted"><?php echo e($post->resource_funds); ?></u>
        </div>
        <div class="card-text">
            <Strong>ชื่อทุน:</Strong>
            <u class="dotted"> <?php echo e($post->funds_category); ?></u>
        </div>
        
        <div class="card-title">
            <h4>⏵ข้อมูลโครงการ</h4>
        </div>
        <div class="border-top my-1"></div>
        <div class="card-text">
            <Strong>รหัสอ้างอิง:</Strong>
            <u class="col"><u class="dotted"><?php echo e($post->ref_id); ?></u></u>
        </div>
        <div class="card-text">
            <Strong>รหัสโครงการ:</Strong>
            <u class="col"><u class="dotted"><?php echo e($post->project_id); ?></u></u>
        </div>
        <div class="card-text">
            <Strong>ประเภทโครงการ:</Strong>
            <u class="dotted"><?php echo e($post->project_category); ?></u>
        </div>
        <div class="card-text">
            <Strong>ลักษณะโครงการ:</Strong>
            <u class="dotted"><?php echo e($post->project_description); ?></u>
        </div>
        <div class="card-text">
            <Strong>คณะ/หน่วยงาน ที่เสนอโครงการ:</Strong>
            <u class="dotted"><?php echo e($post->project_faculty); ?></u>
        </div>
        <div class="card-text">
            <Strong>ชื่อโครงการ(ภาษาไทย):</Strong>
            <u class="dotted"><?php echo e($post->project_name_th); ?></u>
        </div>
        <div class="card-text">
            <Strong>ชื่อโครงการ(ภาษาอังกฤษ):</Strong>
            <u class="dotted"><?php echo e($post->project_name_en); ?></u>
        </div>
        <div class="card-text">
            <Strong>คำสำคัญ:</Strong>
            <u class="dotted"><?php echo e($post->project_keyword); ?></u>
        </div>
        <div class="card-text">
            <Strong>Email(สำหรับติดต่อหัวหน้าโครงการ):</Strong>
            <u class="dotted"><?php echo e($post->project_email_leader); ?></u>
        </div>
        <div class="card-text">
            <Strong>สถานะปัจจุบัน(หัวหน้าโครงการ):</Strong>
            <u class="dotted"><?php echo e($post->project_status_leader); ?></u>
        </div>
        
        <div class="card-title">
            <h4>⏵ระยะเวลาวิจัย</h4>
            
        </div>
        <div class="border-top my-1"></div>
        <div class="card-text">
            <Strong>วันที่เริ่มต้น:</Strong>
            <u class="dotted"><?php echo e(thaidate('j F Y',$post->project_start_at)); ?></u>
        </div>
        <div class="card-text">
            <Strong>วันที่สิ้นสุด:</Strong>
            <u class="dotted"><?php echo e(thaidate('j F Y', $post->project_end_at)); ?></u>
        </div>
        <div class="card-text">
            <Strong>ระยะเวลาโครงการ:</Strong>
            
          <u class="dotted"><?php echo e(\Carbon\Carbon::parse($post->project_start_at)->diffInYears($post->project_end_at)); ?> ปี
            <?php echo e(\Carbon\Carbon::parse($post->project_start_at)->diffInDays($post->project_end_at)-365); ?> วัน</u>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('posts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/posts/show.blade.php ENDPATH**/ ?>