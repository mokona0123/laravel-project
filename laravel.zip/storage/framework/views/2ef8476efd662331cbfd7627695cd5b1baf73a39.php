

<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <h2>Edit Journals</h2>
            <a href="<?php echo e(route('journals.index')); ?>" class="btn btn-primary my-3">
            Back</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <Strong>Whoops!</Strong>
        There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('journals.update', $journals->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <strong>Journals name</strong>
                <input type="text" name="title" value="<?php echo e($journals->title); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong>Description</strong>
                <input type="text" name="description" value="<?php echo e($journals->description); ?>" class="form-control">
            </div>
        </div>
        
        
        <div class="col-md-12">
            <button type="submit" class="btn btn-success my-3">Update</button>
        </div>
    </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('journals.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/journals/edit.blade.php ENDPATH**/ ?>