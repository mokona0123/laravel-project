
<form action="<?php echo e(route('search')); ?>" method="GET">
    <input type="text" name="search" required/>
    <button type="submit">Search</button>
</form>

<?php if($data->isNotEmpty()): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post-list">
            
            <table class="table table-bordered">
                <tr>
                    <th>รหัสอ้างอิง</th>
                    <th>ชื่อโครงการ</th>
                    <th>ทุนวิจัย</th>
                    <th width="280px">Action</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($value->ref_id); ?></td>
                    <td><?php echo e($value->project_name_th); ?></td>
                    <td><?php echo e(Str::limit($value->resource_funds,100)); ?></td>
                    <td>
                        
                        <a href="<?php echo e(route('posts.show', $value->id)); ?>" class="btn btn-primary">Show</a>
                        
                        <?php echo csrf_field(); ?>
                        
                        
            
                        </form>
                    </td>
                </tr>
            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
    <div>
        <h2>No project found</h2>
    </div>
<?php endif; ?>
<?php echo $__env->make('posts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/search.blade.php ENDPATH**/ ?>