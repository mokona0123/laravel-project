
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    

<?php $__env->startSection('content'); ?>
<div class="row mt-5">

 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <?php echo e(__('Project')); ?>

    </h2>
    
 <?php $__env->endSlot(); ?>
<div class="container">
<div class="row">
    
        <div class="col-sm-3">
         
    </div><div class="col-sm-6">
               <form action="<?php echo e(route('search')); ?>" method="GET">
        <div class="form-floating mb-3">
        
        <input type="text" class="form-control" id="floatingInput2" name="search"  placeholder="รหัสอ้างอิง,ชื่อทุน" required>
        
        <label for="floatingInput2">Search...</label>

       </div>  
    </div>
    <div class="col-sm-3">
             <button type="submit" class="btn btn-primary"><i class="fa fa-search fa-2x"></i></button>
 
        </div>
      </form>
        
        </div>
    
    <?php if($data->isNotEmpty()): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post-list">
                
               
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?> 
        <div>
            <h2>No project found</h2>
        </div>
    <?php endif; ?>

    </div>
    
    
<div class="col-md-12">
    <a href="<?php echo e(route ('posts.create')); ?>" class="btn btn-success my-3">Create new project</a>
    
</div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <?php echo e($message); ?>

</div>

<?php endif; ?>
<table class="table table-bordered" id="tb1">
    <tr>
        <th>รหัสอ้างอิง</th>
        <th>ชื่อโครงการ</th>
        <th>ทุนวิจัย</th>
        <th>สถานะ</th>
        <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($value->ref_id); ?></td>
        <td><u class="ttd"><?php echo e($value->project_id); ?></u><?php echo e($value->project_name_th); ?></td>
        <td><?php echo e(Str::limit($value->resource_funds,100)); ?></td>
        <td><?php echo e($value->project_status); ?></td>
        <td>
            <form action="<?php echo e(route('posts.destroy',$value->id)); ?>" method="post">
            <a href="<?php echo e(route('posts.show', $value->id)); ?>" class="btn btn-primary"><i class="fa fa-info"></i></a>
            <a href="<?php echo e(route('posts.edit', $value->id)); ?>" class="btn btn-secondary"><i class="fa fa-cog"></i></a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this?');"><i class="fa fa-trash"></i>
            
            </form>
        </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo $data->links(); ?>

<?php $__env->stopSection(); ?>
              
            
      
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php echo $__env->make('posts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/posts/index.blade.php ENDPATH**/ ?>