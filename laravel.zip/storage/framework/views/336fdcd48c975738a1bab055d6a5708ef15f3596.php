


<?php $__env->startSection('content'); ?>
<div class="row mt-5">
    <div class="col-md-12">
        <h2>Show Fund <?php echo e($fund->id); ?></h2>
        <a href="<?php echo e(route('fund.index')); ?>" class="btn btn-primary my-3">
        Back</a>
    </div>
</div>

<div class="row">
    <div class="card p-3">
        <div class="card-title">
            <strong>ข้อมูลทุน</strong>
        </div>
        <div class="border-top my-1"></div>
        <div class="card-text">
            <Strong>แหล่งทุน:</Strong>
            <?php echo e($fund->resource_funds); ?>

        </div>
        <div class="card-text">
            <Strong>ชื่อทุน:</Strong>
            <?php echo e($fund->funds_category); ?>

        </div>
        
        
        
        <div class="card-text">
            <Strong>ปีงบประมาณ:</Strong>
            <?php echo e($fund->fiscal_year); ?>

        </div>
       
            
    
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('journals.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/fund/show.blade.php ENDPATH**/ ?>