

<?php


$items = DB::table('funds')->get();
$items2 = DB::table('journals')->get();
$selectID=0;
?>
<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <h2>Edit Post</h2>
            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary my-3">
            Back</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <Strong>Whoops!</Strong>
        There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('posts.update', $post->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
    <div class="row">
        
            <div class="card-title">
                <h4>⏵ข้อมูลทุน</h4>
            </div>
            <div class="border-top my-1"></div>
           <div class="col-md-6">
            <div class="form-group">
                <strong>ชื่อทุน</strong>
                
                <select class="form-select" name="resource_funds">

                    <option>Select...</option>
                  
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->resource_funds); ?>" <?php echo e(( $item->resource_funds == $post->resource_funds) ? 'selected' : ''); ?>> <?php echo e($item->resource_funds); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <strong>แหล่งทุน</strong>
                
                <select class="form-select" name="funds_category">

                    <option>Select...</option>
                  
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->funds_category); ?>" <?php echo e(( $item->funds_category == $post->funds_category) ? 'selected' : ''); ?>> <?php echo e($item->funds_category); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
            </div>
        </div>
        <div class="border-top my-4"></div>
        <div class="card-title">
            <h4>⏵ข้อมูลโครงการ</h4>
        </div>
        <div class="border-top my-1"></div>
        <div class="col-md-6">
            <div class="form-group">
                <strong>รหัสอ้างอิง</strong>
                <input type="text" name="ref_id" value="<?php echo e($post->ref_id); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <strong>รหัสโครงการ</strong>
                <input type="text" name="project_id" value="<?php echo e($post->project_id); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong>ประเภทโครงการ</strong>
                <input type="text" name="project_category" value="<?php echo e($post->project_category); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <strong>ลักษณะโครงการ</strong>
                <input type="text" name="project_description" value="<?php echo e($post->project_description); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <strong>คณะ/หน่วยงาน ที่เสนอโครงการ</strong>
                <input type="text" name="project_faculty" value="<?php echo e($post->project_faculty); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong>ชื่อโครงการ(ภาษาไทย)</strong>
                <input type="text" name="project_name_th" value="<?php echo e($post->project_name_th); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong>ชื่อโครงการ(ภาษาอังกฤษ)</strong>
                <input type="text" name="project_name_en" value="<?php echo e($post->project_name_en); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong>คำสำคัญ</strong>
                <input type="text" name="project_keyword" value="<?php echo e($post->project_keyword); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <strong>Email (สำหรับติดต่อหัวหน้าโครงการ)</strong>
                <input type="text" name="project_email_leader" value="<?php echo e($post->project_email_leader); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <strong>สถานะปัจจุบัน</strong>
                <input type="text" name="project_status_leader" value="<?php echo e($post->project_status_leader); ?>" class="form-control">
            </div>
        </div>
        <div class="border-top my-4"></div>
        <div class="col-md-12">
            <div class="form-group">
                <h4>⏵ระยะเวลาการวิจัย</h4>
                <div class="border-top my-1"></div>
 </div>
        </div>
<div class="col-md-6">
    <div class="form-group">
         <strong>วันที่เริ่มต้น</strong>
                <input type="date" name="project_start_at" value="<?php echo e($post->project_start_at); ?>" class="form-control">
    </div>
</div>
               
           
        <div class="col-md-6">
            <div class="form-group">
                
                <strong>วันที่สิ้นสุด</strong>
                <input type="date" name="project_end_at" value="<?php echo e($post->project_end_at); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
         <div class="border-top my-4"></div>
        <div class="col-md-6">
            <div class="form-group">
                <h4>⏵Journals name</h4>
                <div class="border-top my-4"></div> <div class="form-group">
             <strong>Database</strong>
             
             <select class="form-select" name="journal_title">

                 <option>Select...</option>
               
                 <?php $__currentLoopData = $items2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($item2->title); ?>" <?php echo e(( $item2->title == $post->journal_title) ? 'selected' : ''); ?>> <?php echo e($item2->title); ?> </option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    </select>
         </div>
     </div>
     <div class="border-top my-4"></div>
        <div class="col-md-6">
            <div class="form-group">
                <h4>⏵Status</h4>
                <div class="border-top my-4"></div> <div class="form-group">
             <strong>Project status</strong>
             
             <select class="form-select" name="project_status" id="project_status">

                 
               
                 
                    
                        <option value="Incomplete" <?php echo e(old('project_status') == $post->project_status ? 'selected="selected"' : ''); ?> >Incomplete</option>
                    
                        <option value="Complete" <?php echo e(old('project_status') == $post->project_status ? 'selected="selected"' : ''); ?> >Complete</option>
                    
                
                </select>
         </div>
     </div>
        <div class="col-md-12">
            <button type="submit" class="btn btn-success my-3">Update</button>
        </div>
    </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('posts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/posts/edit.blade.php ENDPATH**/ ?>